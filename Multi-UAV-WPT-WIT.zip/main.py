import train
import test
import numpy as np
import matplotlib.pyplot as plt
import configure
import os
import sys
import datetime

# MASACD
# Models_1 : 4 UAV 6 node  [[152., 249.], [148., 250], [80, 150], [84, 151], [220, 150], [216, 151]]


curr_path = os.path.dirname(os.path.abspath(__file__))  # 当前文件所在的绝对路径
parent_path = os.path.dirname(curr_path)  # 父路径
sys.path.append(parent_path)  # 添加路径到系统路径
curr_time = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")  # 获取当前时间
model_name = 'Models_1'


if __name__ == '__main__':
    cfg = configure.Configure()
    sac_model_path = []
    dqn_model_path = []
    for i in range(cfg.uav_num):
        sac_model_path.append(None)
        path = curr_path + "/outputs/policys/" + model_name + "/sac/" + "/{id}/".format(id=i)
        sac_model_path[i] = path
    if cfg.dqnAlgorithm:
        for i in range(cfg.uav_num):
            dqn_model_path.append(None)
            path = curr_path + "/outputs/policys/" + model_name + "/dqn/" + "/{id}/".format(id=i)
            dqn_model_path[i] = path
    sac_data_path = [curr_path + "/outputs/data/" + model_name + "/sac/rewards/",
                     curr_path + "/outputs/data/" + model_name + "/sac/results/"]
    dqn_data_path = ''
    if cfg.dqnAlgorithm:
        dqn_data_path = curr_path + "/outputs/data/" + model_name + "/dqn/rewards/"

    # 训练阶段
    trains = train.Train()
    datas = trains.train()
    for i in range(cfg.uav_num):
        os.makedirs(sac_model_path[i])
        trains.sacAgent[i].save(path=sac_model_path[i])
        if cfg.dqnAlgorithm:
            os.makedirs(dqn_model_path[i])
            trains.dqnAgent[i].save(path=dqn_model_path[i])

    for i in range(len(datas)):
        if i < len(datas)-1:
            os.makedirs(sac_data_path[i])
            np.save(sac_data_path[i], datas[i])
        else:
            if cfg.dqnAlgorithm:
                os.makedirs(dqn_data_path)
                np.save(dqn_data_path, datas[i])

    # wireless node 电量图
    x = np.linspace(1, cfg.T, cfg.T)
    Y = []
    for w in range(cfg.node_num):
        y = []
        for t in range(cfg.T):
            y.append(trains.node.Battery[t, w])
        Y.append(y)
    for w in range(cfg.node_num):
        plt.plot(x, Y[w], label='node_{i}'.format(i=w))
    plt.legend()
    plt.xlabel('t/s')
    plt.ylabel('Battery level of wireless node')
    plt.show()

    # 打印IoT电量
    for w in range(cfg.node_num):
        print("IoT", w, "Battery", trains.node.Battery[:, w])

    # 打印无人机坐标
    X = np.zeros((cfg.uav_num, cfg.T))
    Y = np.zeros((cfg.uav_num, cfg.T))
    for i in range(cfg.uav_num):
        for t in range(cfg.T):
            X[i, t] = trains.uav.uav_co[t, i, 0]
            Y[i, t] = trains.uav.uav_co[t, i, 1]
    for u in range(cfg.uav_num):
        print("UAV", u, "横坐标：", X[u, :])
        print("UAV", u, "纵坐标：", Y[u, :])

    # #
    # # 测试阶段
    test1 = test.Test((sac_model_path, dqn_model_path))
    test1.tes()
    print("UAV电量：", test1.uav.uav_energy[cfg.T-1])

    # IoT电量图
    x = np.linspace(1, cfg.T, cfg.T)
    Y = []
    for w in range(cfg.node_num):
        y = []
        for t in range(cfg.T):
            y.append(test1.node.Battery[t, w])
        Y.append(y)
    for w in range(cfg.node_num):
        plt.plot(x, Y[w], label='iot_{i}'.format(i=w))
    plt.legend()
    plt.xlabel('t/s')
    plt.ylabel('Battery level of wireless node')
    plt.show()

    # 打印IoT电量
    for w in range(cfg.node_num):
        print("IoT", w, "Battery", test1.node.Battery[:, w])

    # IoT ET图
    x = np.linspace(1, cfg.T, cfg.T)
    Y = []
    for u in range(cfg.uav_num):
        y = []
        for t in range(cfg.T):
            y.append(test1.uav.ET[t, u])
        Y.append(y)
    for u in range(cfg.uav_num):
        plt.plot(x, Y[u], label='iot_{i}'.format(i=u))
    plt.legend()
    plt.xlabel('t/s')
    plt.ylabel("UAV's WET decision")
    plt.show()

    # 打印ET
    for u in range(cfg.uav_num):
        print("UAV", u, "ET", test1.uav.ET[:, u])

    # 打印UAV轨迹
    X = np.zeros((cfg.uav_num, cfg.T))
    Y = np.zeros((cfg.uav_num, cfg.T))
    for i in range(cfg.uav_num):
        for t in range(cfg.T):
            X[i, t] = test1.uav.uav_co[t, i, 0]
            Y[i, t] = test1.uav.uav_co[t, i, 1]
    fig = plt.figure()
    ax = fig.add_subplot()
    iot_index = test1.node.node_co

    uav_index = test1.uav.uav_co[0]
    ax.scatter(iot_index[:, 0], iot_index[:, 1], c='red', s=60, marker="^")
    ax.scatter(uav_index[:, 0], uav_index[:, 1], c='blue', s=60, marker="*")
    for i in range(cfg.uav_num):
        ax.plot(X[i, :], Y[i, :], label='UAV-{u}'.format(u=i))
        ax.legend()
    plt.xlim(0, cfg.wide)
    plt.ylim(0, cfg.length)
    plt.grid(True)
    plt.show()

    # 打印无人机坐标
    X = np.zeros((cfg.uav_num, cfg.T))
    Y = np.zeros((cfg.uav_num, cfg.T))
    for i in range(cfg.uav_num):
        for t in range(cfg.T):
            X[i, t] = test1.uav.uav_co[t, i, 0]
            Y[i, t] = test1.uav.uav_co[t, i, 1]
    for u in range(cfg.uav_num):
        print("UAV", u, "横坐标：", X[u, :])
        print("UAV", u, "纵坐标：", Y[u, :])

    # 打印wireless node的CwSum
    for w in range(cfg.node_num):
        print("wireless node", w, "的和率变化:", test1.chann.CwSum[:, w])
