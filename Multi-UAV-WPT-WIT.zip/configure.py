import numpy as np
import torch


class Configure:
    def __init__(self):
        # 系统配置
        self.node_num = 6  # wireless-node 设备数
        self.uav_num = 4  # 无人机数
        self.wide = 300  # 区域宽
        self.length = 300  # 区域长
        self.high = 5  # UAV飞行高度
        self.time = 150  # 时间 150s
        self.deta = 1  # 每1秒为一个时隙
        self.varrho = 0.5  # 子时隙长度
        self.K = int(self.deta/self.varrho)  # 子时隙个数
        self.T = int(self.time / self.deta)  # 任务周期长度
        # 网络配置
        self.episode = 1000  # 训练周期
        self.testEpi = 100  # 测试周期
        self.gamma = 0.99  # 折扣因子
        self.tau = 0.001  # 软跟新参数
        self.buffer_maxLen = 2**17  # 经验存放池大小
        self.value_lr = 3e-4  # 状态值函数学习率
        self.q_lr = 3e-4  # Q函数学习率
        self.policy_lr = 3e-4  # 策略函数学习率
        self.alpha_lr = 2e-4  # 温度学习率
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.batch_size = 128  # 采样大小
        self.edge = 3e-3  # policyNet 中参数的范围
        self.hide_dim = 256  # 隐藏层维度
        self.SAC_state_dim = 3 * self.node_num + 3 * self.uav_num
        self.SAC_observation_dim = 3 * self.node_num + 3
        self.SAC_action_dim = 3
        self.DQN_state_dim = 2 * self.node_num + 3
        self.DQN_action_dim = self.node_num
        self.log_std_min = -20  # self.SAC_action_dim  # policyNet 中的熵最小值
        self.log_std_max = 2  # self.SAC_action_dim  # policyNet 中的熵最大值

        self.epsilon_start = 0.9
        self.epsilon_end = 0.02
        self.lr_start = 0.01
        self.lr_end = 1e-6
        self.epsilon_decay = 5000
        self.lr_decay = 5000
        # 环境配置
        self.noise = -90  # -90dbm
        self.noise_power = np.power(10, self.noise / 10)  # 噪声功率
        self.p_uav_max = 1  # 无人机的传输功率 1w
        self.p_node_max = 0.1  # wireless node 的传输功率 0.1mw
        self.DMin = 2  # 两架无人机的安全距离
        self.VMax = 30  # 无人机的最大速度 30m/s
        self.DCov = 100  # E-node的信令范围
        self.B_Max = 10  # wireless node最大能量储备 10mw*s
        self.B_l = 2  # wireless node 低能量阈值 3mw*s
        self.B_h = 4  # wireless node 高能量阈值 7mw*s
        self.B_exp = (self.B_h-self.B_l) / self.T
        self.UAV_Energy_Max = 200000  # UAV最大电量 250000w*s
        self.UAV_Energy_Min = 20000  # UAV最低电量 20000w*s
        self.PSen = 0.1  # wireless node 的感知功率 0.1mw
        self.PSat = 2  # wireless node 的Psat 2mw
        self.G0 = 1  # d=1m 时的增益
        self.ep = 1  # 计算PLoS的常数 1
        self.a = 12.08  # 计算PLoS的常数 12.08
        self.b = 0.11  # 计算PLoS的常数 0.11
        self.C_min = 100  # 最小传和输率
        self.alphaL = 3  # PLoS因子
        self.alphaN = 5  # PNLoS因子
        # 归一化用的最大瞬时速率
        self.Mmax = np.log2(1 + (self.p_node_max * self.G0) / (self.high ** 2 * self.noise_power)) / 10
        self.CMax = self.T * self.Mmax
        # 实验对比
        self.schedulingAlgorithm = False
        self.dqnAlgorithm = True
        self.fixAlgorithm = False
        self.randomAlgorithm = False