import numpy as np


def function1(x):
    return 0.05 + 0.01 * np.log10(1+x) + 0.02 * (np.log10(1+x)) ** 2 + 0.06 * (np.log10(1+x)) ** 3


class Node:
    def __init__(self, cfg):
        self.cfg = cfg
        self.PMax = self.cfg.p_node_max
        self.NoisePower = self.cfg.noise_power
        self.node_co = np.zeros((self.cfg.node_num, 2), dtype=np.float32)
        self.Flag = np.zeros((self.cfg.T, self.cfg.node_num), dtype=int)
        self.HoE = np.zeros((self.cfg.T, self.cfg.node_num), dtype=int)
        self.Battery = np.zeros((self.cfg.T, self.cfg.node_num), dtype=np.float32)  # mw*s

    def initiateFlag(self):
        self.Flag[0] = 1

    def initiateHoE(self):
        self.HoE[0] = 0

    def normal_RandomInitiateNodeCo(self):
        x = np.random.normal(0, 0.4, self.cfg.node_num)
        y = np.random.normal(0, 0.4, self.cfg.node_num)
        for i in range(self.cfg.node_num):
            self.node_co[i][0] = x[i] * self.cfg.wide / 2 + self.cfg.wide / 2
            self.node_co[i][1] = y[i] * self.cfg.length / 2 + self.cfg.length / 2
            if (self.node_co[i][0] < 0) or (self.node_co[i][0] > self.cfg.wide):
                self.node_co[i][0] = np.random.random() * self.cfg.wide
            if (self.node_co[i][1] < 0) or (self.node_co[i][1] > self.cfg.length):
                self.node_co[i][1] = np.random.random() * self.cfg.length

    def uniform_RandomInitiateIoTCo(self):
        for i in range(self.cfg.node_num):
            self.node_co[i][0] = np.random.random() * self.cfg.wide
            self.node_co[i][1] = np.random.random() * self.cfg.length

    def fix_InitiateIoTCo(self):
        self.node_co = [[152., 249.], [148., 250], [80, 150], [84, 151], [220, 150], [216, 151]]
        self.node_co = np.array(self.node_co)

    def random_InitiateNodeBattery(self):
        self.Battery = np.zeros((self.cfg.T, self.cfg.node_num), dtype=np.float32)  # mw*s
        for i in range(self.cfg.node_num):
            # 0.5 + np.random.random() * self.cfg.B_h
            self.Battery[0][i] = self.cfg.B_l + np.random.random() * (self.cfg.B_h-self.cfg.B_l)  # 初始能量B_l~B_h mw*s

    def fix_InitiateNodeBattery(self):
        self.Battery = np.zeros((self.cfg.T, self.cfg.node_num), dtype=np.float32)  # mw*s
        self.Battery[0] = [4.5, 6.8, 3.2, 7.4, 3.5, 8.5]

    def functionE(self, harvestedP):
        p_min = function1(self.cfg.PSen) * self.cfg.PSen
        if harvestedP < self.cfg.PSen:
            return 0
        elif harvestedP >= self.cfg.PSen and (harvestedP < self.cfg.PSat):
            return function1(harvestedP) * harvestedP - p_min
        return function1(self.cfg.PSat) * self.cfg.PSat - p_min
