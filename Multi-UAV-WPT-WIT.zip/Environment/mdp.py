import numpy as np


class MDP:
    def __init__(self, cfg, chann, xi1=0.25, xi2=1, xi3=1e-5):  # xi3=0.08
        self.cfg = cfg
        self.chann = chann
        self.xi1 = xi1
        self.xi2 = xi2
        self.xi3 = xi3

    def getStateSAC(self, t):
        state = np.zeros((self.cfg.SAC_state_dim,), dtype=np.float32)
        for u in range(self.cfg.uav_num):
            state[2 * u] = self.chann.uav.uav_co[t, u, 0] / self.cfg.wide
            state[2 * u + 1] = self.chann.uav.uav_co[t, u, 1] / self.cfg.length
        index = 2 * self.cfg.uav_num
        for w in range(self.cfg.node_num):
            state[index + w] = self.chann.node.Flag[t, w]
        index += self.cfg.node_num
        for w in range(self.cfg.node_num):
            state[index + w] = self.chann.node.HoE[t, w]
        # index += self.cfg.node_num
        # for w in range(self.cfg.node_num):
        #     state[index + w] = self.chann.CwSum[t, w] / self.cfg.CMax
        # index += self.cfg.node_num
        # for w in range(self.cfg.node_num):
        #     state[index + w] = self.chann.Cw[t, w] / self.cfg.CMax * self.cfg.T
        index += self.cfg.node_num
        for w in range(self.cfg.node_num):
            state[index + w] = self.chann.BState[w] / self.cfg.B_Max
        # index += self.cfg.node_num
        # for w in range(self.cfg.node_num):
        #     state[index + 2*w] = self.chann.node.node_co[w, 0] / self.cfg.wide
        #     state[index + 2*w+1] = self.chann.node.node_co[w, 1] / self.cfg.length
        # index += 2 * self.cfg.node_num
        for u in range(self.cfg.uav_num):
            state[index + u] = self.chann.uav.uav_energy[t, u] / self.cfg.UAV_Energy_Max
        return state

    def getObservationSAC(self, t):
        observation = np.zeros((self.cfg.uav_num, self.cfg.SAC_observation_dim), dtype=np.float32)
        for u in range(self.cfg.uav_num):
            index = 0
            observation[u, index] = self.chann.uav.uav_co[t, u, 0] / self.cfg.wide
            index += 1
            observation[u, index] = self.chann.uav.uav_co[t, u, 1] / self.cfg.length
            index += 1
            for w in range(self.cfg.node_num):
                observation[u, index + w] = self.chann.node.Flag[t, w]
            index += self.cfg.node_num
            for w in range(self.cfg.node_num):
                observation[u, index + w] = self.chann.node.HoE[t, w]
            # index += self.cfg.node_num
            # for w in range(self.cfg.node_num):
            #     observation[u, index + w] = self.chann.CwSum[t, w] / self.cfg.CMax
            index += self.cfg.node_num
            # for w in range(self.cfg.node_num):
            #     observation[u, index + w] = self.chann.Cw[t, w] / self.cfg.CMax * self.cfg.T
            # index += self.cfg.node_num
            for w in range(self.cfg.node_num):
                observation[u, index + w] = self.chann.Bwu[u, w] / self.cfg.B_Max
            index += self.cfg.node_num
            # for w in range(self.cfg.node_num):
            #     observation[u, index + 2 * w] = self.chann.node.node_co[w, 0] / self.cfg.wide
            #     observation[u, index + 2 * w + 1] = self.chann.node.node_co[w, 1] / self.cfg.length
            # index += 2 * self.cfg.node_num
            observation[u, index] = self.chann.uav.uav_energy[t, u] / self.cfg.UAV_Energy_Max
        return observation

    def getRewardSAC(self, t, weightEnergy, difference, exceedAreaNum, collisionNum, dist, sumHoE, firstExceedNum):
        r = np.zeros((self.cfg.uav_num,), dtype=np.float32)
        for u in range(self.cfg.uav_num):
            rc = 0.
            # for w in range(self.cfg.node_num):
            #     if self.chann.node.Flag[t, w] == 0:
            #         rc += (self.chann.CwSum[t, w] - self.cfg.C_min * t / self.cfg.T)
            #     else:
            #         rc += self.chann.Cw[t, w]
            r0 = (100 * (difference*weightEnergy[u])+
                  self.xi3*(self.chann.uav.uav_energy[t, u]-self.cfg.UAV_Energy_Min)) /\
                 (1+sumHoE* np.exp(-weightEnergy[u])) + 0.0001*rc + 0.1*dist[u] + 20 * firstExceedNum
            r1 = exceedAreaNum[u] + collisionNum[u]
            r[u] = self.xi1 * r0 - self.xi2 * r1
        return r

    def getStateDQN(self, t):
        state = np.zeros((self.cfg.uav_num, self.cfg.K, self.cfg.DQN_state_dim), dtype=np.float32)
        for u in range(self.cfg.uav_num):
            for k in range(self.cfg.K):
                # 第 u 架UAV的第 k 个子时隙的状态
                s = np.zeros((self.cfg.DQN_state_dim,), dtype=np.float32)
                s[0] = self.chann.uav.uav_co[t, u, 0] / self.cfg.wide
                s[1] = self.chann.uav.uav_co[t, u, 1] / self.cfg.length
                index = 2
                for w in range(self.cfg.node_num):
                    s[index + w] = self.chann.M[t, k, u, w] / self.cfg.Mmax
                index += self.cfg.node_num
                for w in range(self.cfg.node_num):
                    s[index + w] = self.chann.CwSum[t, w] / self.cfg.CMax
                index += self.cfg.node_num
                s[index] = k / self.cfg.K
                state[u, k] = s
        return state

    def getRewardDQN(self, t):
        r = np.zeros((self.cfg.uav_num, self.cfg.K), dtype=np.float32)
        for u in range(self.cfg.uav_num):
            for k in range(self.cfg.K):
                rm = 0.
                for w in range(self.cfg.node_num):
                    if self.chann.node.Flag[t, w] == 1:
                        # rm += self.chann.M[t, k, u, w] / (1+self.chann.CwSum[t, w])
                        rm += self.chann.M[t, k, u, w]
                    else:
                        rm += 0.01 * self.chann.CwSum[t, w]
                r[u, k] = rm
        return r
