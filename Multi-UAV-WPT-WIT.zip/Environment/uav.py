import numpy as np


def functionP(V):
    rho = 1.225
    R = 0.5
    W = 100
    e = 0.05
    A = 0.79
    delta = 0.012
    Omega = 400
    k = 0.1
    Pb = delta / 8 * rho * e * A * Omega ** 3 * R ** 3
    Pu = (1 + k) * W ** 1.5 / (2 * rho * A) ** 0.5
    V_tip = 200
    e0 = 7.2
    f0 = 0.3
    return Pb*(1+3*V*V/V_tip**2)+Pu*((1+V**4/4/e0**4)**0.5-V**2/2/e0**2)**0.5 + 0.5*f0*rho*e*A*V**3


class UAV:
    def __init__(self, cfg):
        self.cfg = cfg
        self.PMax = self.cfg.p_uav_max
        self.uav_co = np.zeros((self.cfg.T, self.cfg.uav_num, 2), dtype=np.float32)
        self.H = self.cfg.high
        self.d_min = self.cfg.DMin
        self.v_max = self.cfg.VMax
        self.p_max = self.cfg.p_uav_max
        self.EnergyMax = self.cfg.UAV_Energy_Max
        self.uav_energy = np.zeros((self.cfg.T, self.cfg.uav_num), dtype=np.float32)
        self.ET = np.zeros((self.cfg.T, self.cfg.uav_num), dtype=int)

    def initiateET(self):
        for i in range(self.cfg.uav_num):
            self.ET[0, i] = 0

    def updateET(self, t, E):  # t>0
        self.ET[t] = E

    def initiateUAVEnergy(self):
        self.uav_energy = np.zeros((self.cfg.T, self.cfg.uav_num), dtype=np.float32)
        for i in range(self.cfg.uav_num):
            self.uav_energy[0, i] = self.EnergyMax

    def initiateUAVCo(self):
        self.uav_co = np.zeros((self.cfg.T, self.cfg.uav_num, 2), dtype=np.float32)
        for i in range(self.cfg.uav_num):
            self.uav_co[0] = [60., 120.], [140., 140.], [120., 180.]

    def uniform_RandomInitiateUAVTCo(self):
        self.uav_co = np.zeros((self.cfg.T, self.cfg.uav_num, 2), dtype=np.float32)
        for i in range(self.cfg.uav_num):
            self.uav_co[0, i, 0] = np.random.random() * self.cfg.wide
            self.uav_co[0, i, 1] = np.random.random() * self.cfg.length

    def updateUAVCo(self, t, alpha, v):  # alpha 水平转角 v 速度
        exceedAreaNum = np.zeros((self.cfg.uav_num,))
        collisionNum = np.zeros((self.cfg.uav_num,))
        for i in range(self.cfg.uav_num):
            self.uav_co[t, i, 0] = v[i] * self.cfg.deta * np.cos(alpha[i]) + self.uav_co[t-1, i, 0]
            self.uav_co[t, i, 1] = v[i] * self.cfg.deta * np.sin(alpha[i]) + self.uav_co[t-1, i, 1]
            if (self.uav_co[t, i, 0] > self.cfg.wide) or (self.uav_co[t, i, 0] < 0) or \
               (self.uav_co[t, i, 1] > self.cfg.length) or (self.uav_co[t, i, 1] < 0):
                exceedAreaNum[i] += 1
        for i in range(self.cfg.uav_num):
            for j in range(self.cfg.uav_num):
                if j != i:
                    distance = (self.uav_co[t, i, 0]-self.uav_co[t, j, 0])**2 + \
                               (self.uav_co[t, i, 1]-self.uav_co[t, j, 1])**2
                    if distance < self.cfg.DMin**2:
                        collisionNum[i] += 1
        # for i in range(self.cfg.uav_num):
        #     if (self.uav_co[t, i, 0] > self.cfg.wide) or (self.uav_co[t, i, 0] < 0):
        #         self.uav_co[t, i, 0] = -v[i] * self.cfg.deta * np.cos(alpha[i]) + self.uav_co[t - 1, i, 0]
        #     if (self.uav_co[t, i, 1] > self.cfg.length) or (self.uav_co[t, i, 1] < 0):
        #         self.uav_co[t, i, 1] = -v[i] * self.cfg.deta * np.sin(alpha[i]) + self.uav_co[t - 1, i, 1]
        return exceedAreaNum, collisionNum

    def updateUAVEnergy(self, t, v):  # t>0
        for i in range(self.cfg.uav_num):
            self.uav_energy[t, i] = self.uav_energy[t-1, i] - functionP(v[i]) * self.cfg.deta \
                                    - self.ET[t, i] * self.PMax * self.cfg.deta
