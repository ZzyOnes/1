import numpy as np


class Channel:
    def __init__(self, uav, node, cfg):
        self.uav = uav
        self.node = node
        self.cfg = cfg
        self.Gw = np.zeros((self.cfg.T, self.cfg.uav_num, self.cfg.node_num), dtype=np.float32)
        self.sinr = np.zeros((self.cfg.T, self.cfg.K, self.cfg.uav_num, self.cfg.node_num), dtype=np.float32)
        self.M = np.zeros((self.cfg.T, self.cfg.K, self.cfg.uav_num, self.cfg.node_num), dtype=np.float32)  # 传输率
        self.D = np.zeros((self.cfg.T, self.cfg.K, self.cfg.uav_num, self.cfg.node_num), dtype=np.float32)  # 任务调度
        self.dw = np.zeros((self.cfg.uav_num, self.cfg.node_num), dtype=np.float32)  # uav与w的距离
        self.PLoSw = np.zeros((self.cfg.uav_num, self.cfg.node_num), dtype=np.float32)
        self.Cw = np.zeros((self.cfg.T, self.cfg.node_num), dtype=np.float32)  # 和率
        self.CwSum = np.zeros((self.cfg.T, self.cfg.node_num), dtype=np.float32)  # 累积和率
        self.Bwu = np.zeros((self.cfg.uav_num, self.cfg.node_num), dtype=np.float32)
        self.BState = np.zeros((self.cfg.node_num,), dtype=np.float32)
        self.N = np.zeros((self.cfg.uav_num,), dtype=int)  # 每架UAV覆盖的E-node个数

    def updateDw(self, t):
        dist = np.zeros((self.cfg.uav_num,), dtype=np.float32)
        for u in range(self.cfg.uav_num):
            for w in range(self.cfg.node_num):
                self.dw[u][w] = (((self.uav.uav_co[t][u][0] - self.node.node_co[w][0]) ** 2 +
                                  (self.uav.uav_co[t][u][1] - self.node.node_co[w][
                                      1]) ** 2) + self.cfg.high ** 2) ** 0.5
                if (self.node.Flag[t, w] == 0) and (self.dw[u][w] <= self.cfg.DCov) and \
                        (0 <= self.uav.uav_co[t, u, 0] <= self.cfg.wide) and \
                        (0 <= self.uav.uav_co[t, u, 1] <= self.cfg.length):
                    dist[u] += self.node.HoE[t, w] / (1 + self.dw[u][w])
                    self.N[u] += 1
        return dist

    def getBwu(self, t):  # 先更新dw
        for u in range(self.cfg.uav_num):
            for w in range(self.cfg.node_num):
                if self.node.Flag[t, w] == 1:
                    self.Bwu[u, w] = self.node.Battery[t, w]
                else:
                    if self.dw[u, w] <= self.cfg.DCov:
                        self.Bwu[u, w] = self.node.Battery[t, w]
                    else:
                        self.Bwu[u, w] = self.node.Battery[t, w]

    def getBState(self, t):
        t1 = t if t > 0 else 1
        for w in range(self.cfg.node_num):
            if self.node.Flag[t, w] == 1:
                self.BState[w] = self.node.Battery[t, w]
            else:
                flag1 = 0
                for u in range(self.cfg.uav_num):
                    if self.dw[u, w] <= self.cfg.DCov:
                        flag1 = 1
                if flag1 == 1:
                    self.BState[w] = self.node.Battery[t, w]
                else:
                    self.BState[w] = self.node.Battery[t1 - 1, w]

    #  随机初始话任务调度
    def randomUpdateD(self, t):  # 初始化时令t=0
        self.D[t] = 0
        for k in range(self.cfg.K):
            flags = np.zeros((self.cfg.node_num,), dtype=int)
            for i in range(self.cfg.uav_num):
                id = np.random.randint(0, self.cfg.node_num)
                num = 0
                while self.node.Flag[t, id] == 0 and (num < 2 * self.cfg.node_num):
                    id = np.random.randint(0, self.cfg.node_num)
                    num += 1
                if flags[id] == 0:
                    flags[id] = 1
                else:
                    num = 0
                    while (flags[id] == 1 or self.node.Flag[t, id] == 0) and (num < 2 * self.cfg.node_num):
                        id = (id + 1) % self.cfg.node_num
                        num += 1
                    flags[id] = 1
                self.D[t, k, i, id] = 1

    # 固定任务调度 优先最近原则
    def fixUpdateD(self, t):
        self.D[t] = 0
        for k in range(self.cfg.K):
            flags = np.zeros((self.cfg.node_num,), dtype=int)
            for i in range(self.cfg.uav_num):
                List = self.dw[i].tolist()
                for w in range(self.cfg.node_num):
                    if self.node.Flag[t, w] == 0:
                        List[w] = 1e9
                id = List.index(min(List))
                List[id] = 1e9
                if flags[id] != 1:
                    flags[id] = 1
                    self.D[t, k, i, id] = 1
                else:
                    num = 0
                    while flags[id] == 1 and num<self.cfg.node_num:
                        id = List.index(min(List))
                        List[id] = 1e9
                        num += 1
                    flags[id] = 1
                    self.D[t, k, i, id] = 1

    def updateD(self, t, D_):  # t>0
        self.D[t] = D_

    def updatePLoSw(self):
        for i in range(self.cfg.uav_num):
            for j in range(self.cfg.node_num):
                omega = np.arcsin(self.cfg.high / self.dw[i, j])
                self.PLoSw[i, j] = 1 / (1 + self.cfg.a * np.exp(-self.cfg.b * (180 / np.pi * omega - self.cfg.a)))

    def updateGw(self, t):
        for i in range(self.cfg.uav_num):
            for j in range(self.cfg.node_num):
                self.Gw[t, i, j] = self.cfg.G0 * (
                        self.PLoSw[i, j] * self.dw[i, j] ** -self.cfg.alphaL + (1 - self.PLoSw[i, j])
                        * self.dw[i, j] ** -self.cfg.alphaN)

    def updateSinr(self, t):
        self.sinr[t] = 0
        for k in range(self.cfg.K):
            for j in range(self.cfg.node_num):
                for i in range(self.cfg.uav_num):
                    if self.D[t, k, i, j] != 0:
                        sinr_ = self.cfg.noise_power
                        for j_ in range(self.cfg.node_num):
                            if j != j_:
                                flag = 0
                                for i_ in range(self.cfg.uav_num):
                                    if self.D[t, k, i_, j_] == 1:
                                        flag = 1
                                sinr_ += flag * self.node.Flag[t, j_] * self.cfg.p_node_max * self.Gw[t, i, j_]
                        self.sinr[t, k, i, j] = self.cfg.p_node_max * self.node.Flag[t, j] * self.Gw[
                            t, i, j] / sinr_

    def updateM(self, t):
        for k in range(self.cfg.K):
            for u in range(self.cfg.uav_num):
                for w in range(self.cfg.node_num):
                    self.M[t, k, u, w] = np.log2(1 + self.sinr[t, k, u, w])

    def updateCw(self, t):
        self.Cw[t] = 0.
        for w in range(self.cfg.node_num):
            sumM = 0.
            for k in range(self.cfg.K):
                for u in range(self.cfg.uav_num):
                    sumM += self.M[t, k, u, w]
            self.Cw[t, w] = sumM

    def initiateCwSum(self):
        self.CwSum[0] = self.Cw[0]

    def updateCwSum(self, t):  # t>0
        self.CwSum[t] = 0.
        for w in range(self.cfg.node_num):
            self.CwSum[t, w] = self.CwSum[t - 1, w] + self.Cw[t, w]

    def updateBatteryForENode(self, t):  # t>0
        difference = 0.
        charge = 0.
        sumHoE = 0
        firstExceedNum = 0
        weight = np.zeros((self.cfg.uav_num,))
        for w in range(self.cfg.node_num):
            harvestedP = 0.
            for i in range(self.cfg.uav_num):
                harvestedP += self.uav.ET[t - 1, i] * self.cfg.p_uav_max * 1000 * self.Gw[t, i, w]
            for i in range(self.cfg.uav_num):
                if harvestedP >= self.cfg.PSen:
                    weight[i] += self.uav.ET[t - 1, i] * self.cfg.p_uav_max * 1000 * self.Gw[t, i, w] / harvestedP
            harvestedEnergy = self.node.functionE(harvestedP) * self.cfg.deta
            energy = self.node.Battery[t - 1, w] + harvestedEnergy
            self.node.Battery[t, w] = energy if energy <= self.cfg.B_Max else self.cfg.B_Max
            if self.node.Flag[t - 1, w] == 0:
                if self.node.Battery[t, w] - self.node.Battery[t - 1, w] >= self.cfg.B_exp:
                    self.node.HoE[t, w] = max(self.node.HoE[t - 1, w] - 1, 1)
                else:
                    self.node.HoE[t, w] = self.node.HoE[t - 1, w] + 1
            else:
                if self.node.Battery[t, w] >= self.cfg.B_h:
                    self.node.HoE[t, w] = 0
                else:
                    self.node.HoE[t, w] = 1
            difference += (self.node.Battery[t, w] - self.node.Battery[t - 1, w]) * self.node.HoE[t, w]
            charge += (self.node.Battery[t, w] - self.node.Battery[t - 1, w])
            sumHoE += self.node.HoE[t, w]
            if (self.node.Battery[t - 1, w] < self.cfg.B_h) and self.node.Battery[t, w] \
                    >= self.cfg.B_h:
                firstExceedNum += 1

        return difference, weight, sumHoE, firstExceedNum, charge

    def updateBatteryForINode(self, t):  # t>0
        for w in range(self.cfg.node_num):
            if self.node.Flag[t - 1, w] == 1:
                energy = 0.
                for u in range(self.cfg.uav_num):
                    for k in range(self.cfg.K):
                        energy += self.D[t - 1, k, u, w] * self.cfg.p_node_max * self.cfg.varrho
                self.node.Battery[t, w] -= energy

    def updateFlag(self, t):  # t>0
        for w in range(self.cfg.node_num):
            if self.node.Battery[t, w] >= self.cfg.B_l:
                self.node.Flag[t, w] = 1
            else:
                self.node.Flag[t, w] = 0

    # scheduling Algorithm ##########
    def scheduling(self, t):
        self.D[t] = 0
        Cw_ = self.CwSum[t]
        for w in range(self.cfg.node_num):
            if self.node.Flag[t, w] == 0:
                Cw_[w] = 1e9
        for k in range(self.cfg.K):
            Darr = []
            for u in range(self.cfg.uav_num):
                for w in range(self.cfg.node_num):
                    if self.node.Flag[t, w] == 1:
                        Darr.append(
                            [u, w, (Cw_[w] / (1 + np.log2(1 + self.cfg.p_node_max * self.Gw[t, u, w] /
                                                          self.cfg.noise_power)))])
            Darr = np.array(Darr)
            if len(Darr) == 0:
                return
            DarrId = np.lexsort(Darr.T)
            flag1 = np.zeros((self.cfg.uav_num,), dtype=int)
            flag2 = np.zeros((self.cfg.node_num,), dtype=int)
            sums = 0
            idx = 0
            while sums < self.cfg.uav_num and idx < len(DarrId):
                id = DarrId[idx]
                u, w = Darr[id, 0], Darr[id, 1]
                u = int(u)
                w = int(w)
                if flag1[u] == 0 and flag2[w] == 0:
                    self.D[t, k, u, w] = 1
                    flag1[u] = 1
                    flag2[w] = 1
                    sums += 1
                idx += 1
            for w in range(self.cfg.node_num):
                M_ = 0.
                for u in range(self.cfg.uav_num):
                    if self.D[t, k, u, w] == 1:
                        noise = self.cfg.noise_power
                        for w_ in range(self.cfg.node_num):
                            if w_ != w:
                                flag = 0
                                for u_ in range(self.cfg.uav_num):
                                    if self.D[t, k, u_, w_] == 1:
                                        flag = 1
                                noise += flag * self.node.Flag[t, w_] * self.cfg.p_node_max * self.Gw[t, u, w_]
                        M_ = np.log2(1 + (self.node.Flag[t, w] * self.cfg.p_node_max * self.Gw[t, u, w] / noise))
                Cw_[w] += M_
