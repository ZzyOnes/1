import numpy as np
import matplotlib.pyplot as plt
import configure
cfg = configure.Configure()


def getMe(r):
    me_r = [r[0]]
    for i in range(1, cfg.episode):
        me_r.append(me_r[i-1]*0.9 + 0.1*r[i])
    return me_r


def plotReward():
    reward_1 = np.load("outputs/data/Models_1/sac/rewards/.npy")
    me_reward_1 = getMe(reward_1)
    reward_2 = np.load("outputs/data/Models_2/sac/rewards/.npy")
    me_reward_2 = getMe(reward_2)
    reward_3 = np.load("outputs/data/Models_3/sac/rewards/.npy")
    me_reward_3 = getMe(reward_3)
    reward_4 = np.load("outputs/data/Models_4/sac/rewards/.npy")
    me_reward_4 = getMe(reward_4)
    plt.plot(reward_1, alpha=0.15, color='r')
    plt.plot(me_reward_1, color='r', label='MASACD')
    plt.plot(reward_2, alpha=0.15, color='b')
    plt.plot(me_reward_2, color='b', label='MASACS')
    plt.plot(reward_3, alpha=0.15, color='c')
    plt.plot(me_reward_3, color='c', label='MASAC-Random')
    plt.plot(reward_4, alpha=0.15, color='orange')
    plt.plot(me_reward_4, color='orange', label='MASAC-Fix')
    plt.legend()
    plt.grid(True)
    plt.show()


def plotResult():
    result_1 = np.load("outputs/data/Models_1/sac/results/.npy")
    me_result_1 = getMe(result_1)
    result_2 = np.load("outputs/data/Models_2/sac/results/.npy")
    me_result_2 = getMe(result_2)
    result_3 = np.load("outputs/data/Models_3/sac/results/.npy")
    me_result_3 = getMe(result_3)
    result_4 = np.load("outputs/data/Models_4/sac/results/.npy")
    me_result_4 = getMe(result_4)
    plt.plot(result_1, alpha=0.15, color='r')
    plt.plot(me_result_1, color='r', label='MASACD')
    plt.plot(result_2, alpha=0.15, color='b')
    plt.plot(me_result_2, color='b', label='MASACS')
    plt.plot(result_3, alpha=0.15, color='c')
    plt.plot(me_result_3, color='c', label='MASAC-Random')
    plt.plot(result_4, alpha=0.15, color='orange')
    plt.plot(me_result_4, color='orange', label='MASAC-Fix')
    plt.legend()
    plt.grid(True)
    plt.show()


if __name__ == '__main__':
    plotReward()
    plotResult()
