import configure
import numpy as np
from Environment import wirelessNode
from Environment import uav
from Environment import channel
from Environment import mdp
from SACAlgorithm import sac
from DQNAlgorithm import dqn


class Test:
    def __init__(self, model_path):
        self.sac_model_path = model_path[0]
        self.cfg = configure.Configure()
        self.cfg.epsilon_start = self.cfg.epsilon_end
        if self.cfg.dqnAlgorithm:
            self.dqn_model_path = model_path[1]
        self.node = wirelessNode.Node(self.cfg)
        self.uav = uav.UAV(self.cfg)
        self.chann = channel.Channel(self.uav, self.node, self.cfg)
        self.mdp = mdp.MDP(self.cfg, self.chann)
        self.sacAgent = []
        self.dqnAgent = []
        for i in range(self.cfg.uav_num):
            self.sacAgent.append(None)
            self.sacAgent[i] = sac.SAC(self.cfg)
            self.sacAgent[i].load(path=self.sac_model_path[i])
            if self.cfg.dqnAlgorithm:
                self.dqnAgent.append(None)
                self.dqnAgent[i] = dqn.DQN(self.cfg)
                self.dqnAgent[i].load(path=self.dqn_model_path[i])
        self.v_max_2 = self.uav.v_max / 2
        self.node.fix_InitiateIoTCo()

    def tes(self):
        print("开始测试！ 设备为{device}".format(device=self.cfg.device))
        for episode in range(self.cfg.testEpi):
            sac_rewards = 0.
            dqn_rewards = 0.
            sumCharge = 0.
            chargeB_h = 0
            exceedAreaNums, collisionNums = 0., 0.
            # 初始化
            self.uav.uniform_RandomInitiateUAVTCo()
            self.uav.initiateET()
            self.uav.initiateUAVEnergy()
            self.node.random_InitiateNodeBattery()
            self.node.initiateFlag()
            _ = self.chann.updateDw(0)  # 初始化uav与wireless node之间的距离
            self.chann.getBwu(0)
            self.chann.getBState(0)
            self.chann.updatePLoSw()
            self.chann.updateGw(0)
            self.chann.scheduling(0)  # 始化任务调度
            self.chann.updateSinr(0)
            self.chann.updateM(0)
            self.chann.updateCw(0)
            self.chann.initiateCwSum()

            sacState = self.mdp.getStateSAC(0)
            sacObservation = self.mdp.getObservationSAC(0)
            dqnState = self.mdp.getStateDQN(0)  # [uav_num, K, action_dim]
            for t in range(1, self.cfg.T):
                sacAction = np.zeros((self.cfg.SAC_action_dim * self.cfg.uav_num,))
                for i in range(self.cfg.uav_num):
                    action = np.array(self.sacAgent[i].get_action(sacObservation[i])).reshape(self.cfg.SAC_action_dim, )
                    sacAction[i] = action[0]
                    sacAction[self.cfg.uav_num + i] = action[1]
                    sacAction[2 * self.cfg.uav_num + i] = action[2]
                # sac 动作解码
                v, alpha, ET = self.getSACAction(sacAction)
                D_ = np.zeros((self.cfg.K, self.cfg.uav_num, self.cfg.node_num))
                dqnActions = np.zeros((self.cfg.uav_num, self.cfg.K), dtype=int)
                if self.cfg.dqnAlgorithm:
                    for k in range(self.cfg.K):
                        used = []
                        for i in range(self.cfg.uav_num):
                            dqnAction, q_values = self.dqnAgent[i].choose_action(dqnState[i, k])
                            # dqn 动作解码
                            id = self.getDQNAction(dqnAction, q_values, used)
                            used.append(id)
                            D_[k, i, id] = 1
                            dqnActions[i, k] = id
                # 得到动作v,alpha,ET, D 后开始更新
                exceedAreaNum, collisionNum = self.uav.updateUAVCo(t, alpha, v)
                exceedAreaNums += sum(exceedAreaNum)
                collisionNums += sum(collisionNum)
                self.uav.updateET(t, ET)
                self.uav.updateUAVEnergy(t, v)
                dist = self.chann.updateDw(t)
                if self.cfg.dqnAlgorithm:
                    self.chann.updateD(t, D_)
                elif self.cfg.schedulingAlgorithm:
                    self.chann.scheduling(t)
                elif self.cfg.fixAlgorithm:
                    self.chann.fixUpdateD(t)
                elif self.cfg.randomAlgorithm:
                    self.chann.randomUpdateD(t)
                self.chann.updatePLoSw()
                self.chann.updateGw(t)
                self.chann.updateSinr(t)
                self.chann.updateM(t)
                self.chann.updateCw(t)
                self.chann.updateCwSum(t)
                difference, weight, sumHoE, firstExceedNum, charge = self.chann.updateBatteryForENode(t)
                sumCharge += charge
                chargeB_h += firstExceedNum
                self.chann.updateBatteryForINode(t)
                self.chann.updateFlag(t)
                sacState_ = self.mdp.getStateSAC(t)
                sacObservation_ = self.mdp.getObservationSAC(t)
                r_sac = self.mdp.getRewardSAC(t, weight, difference, exceedAreaNum, collisionNum, dist,
                                              sumHoE, firstExceedNum)
                sac_rewards += r_sac.mean()
                r_dqn = 0.
                dqnState_ = 0.
                if self.cfg.dqnAlgorithm:
                    dqnState_ = self.mdp.getStateDQN(t)
                    r_dqn = self.mdp.getRewardDQN(t)
                    dqn_rewards += r_dqn.mean()

                # 经验存储
                for i in range(self.cfg.uav_num):
                    action = np.zeros((self.cfg.SAC_action_dim,))
                    action[0] = sacAction[i]
                    action[1] = sacAction[self.cfg.uav_num + i]
                    action[2] = sacAction[2 * self.cfg.uav_num + i]
                    self.sacAgent[i].buffer.push((sacState, action, r_sac[i], sacState_, sacObservation[i]))
                if self.cfg.dqnAlgorithm:
                    for i in range(self.cfg.uav_num):
                        for k in range(self.cfg.K):
                            self.dqnAgent[i].memory.push((dqnState[i, k], dqnActions[i, k], r_dqn[i, k],
                                                          dqnState_[i, k]))
                sacState = sacState_
                sacObservation = sacObservation_
                if self.cfg.dqnAlgorithm:
                    dqnState = dqnState_
            averageUAVEnergy = np.mean(self.uav.uav_energy[self.cfg.T - 1])
            result = np.sum(self.chann.CwSum[self.cfg.T-1])
            print("episode:{},Result:{} SACReward:{}, DQNReward:{}, averageUAVEnergy:{}, SumWCharge:{}, exceedArea:{},"
                  " collision:{}".format(episode + 1, result, sac_rewards, dqn_rewards, averageUAVEnergy,
                                                     sumCharge,
                                                     exceedAreaNums, collisionNums))
            if sumCharge > 9 and result > 1000:
                break
        print("Finish test!")

    def getSACAction(self, action):
        v = action[:self.cfg.uav_num] * self.v_max_2 + self.v_max_2
        alpha = action[self.cfg.uav_num:2 * self.cfg.uav_num] * np.pi + np.pi
        ET = action[self.cfg.uav_num * 2:]
        for i in range(self.cfg.uav_num):
            ET[i] = 0 if ET[i] <= 0 else 1
        return v, alpha, np.array(ET, dtype=int)

    def getDQNAction(self, action, q_values, used):
        if action not in used:
            return action
        List = np.array(q_values).reshape(self.cfg.DQN_action_dim, ).tolist()
        List[action] = -1e9
        id = List.index(max(List))
        while id in used:
            List[id] = -1e9
            id = List.index(max(List))
        return id
